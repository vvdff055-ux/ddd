package com.kodari.hauntedfog;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ThreadLocalRandom;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttribute;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.VexEntity;
import net.minecraft.entity.passive.PassiveEntity;
import net.minecraft.entity.passive.VillagerEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/**
 * All the haunting logic. Ghosts are vanilla Vexes (tagged, bigger, tougher, retextured by the mod's resource pack),
 * so no custom entity registration is needed and one jar works across many Minecraft versions.
 */
public final class HauntManager {
    public static final String TAG = "hauntedfog_ghost";

    /** Ghosts kept alive around every player. */
    private static final int GHOSTS_PER_PLAYER = 40;
    /** Extra ghosts when a village is nearby. */
    private static final int VILLAGE_EXTRA = 20;
    /** No ghosts for the first 30 seconds after joining. */
    private static final int GRACE_TICKS = 600;
    /** Ticks between being grabbed and being thrown out of the game. */
    private static final int SCARE_TICKS = 25;
    private static final double CATCH_DISTANCE = 2.6;
    private static final double GHOST_SCALE = 2.3;

    private static final Map<UUID, Integer> GRABBED = new ConcurrentHashMap<>();
    private static final Queue<BlockPos> CORPSES = new ConcurrentLinkedQueue<>();

    private static final SoundEvent[] WHISPERS = {
            SoundEvents.ENTITY_VEX_AMBIENT,
            SoundEvents.ENTITY_PHANTOM_AMBIENT,
            SoundEvents.ENTITY_GHAST_AMBIENT,
            SoundEvents.ENTITY_ZOMBIE_VILLAGER_AMBIENT,
            SoundEvents.ENTITY_ENDERMAN_STARE
    };

    private HauntManager() {
    }

    public static void register() {
        ServerTickEvents.END_WORLD_TICK.register(HauntManager::tick);
        ServerLifecycleEvents.SERVER_STOPPING.register(server -> {
            GRABBED.clear();
            CORPSES.clear();
        });

        // A villager killed by a ghost leaves a corpse and blood behind.
        ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
            if (entity instanceof VillagerEntity
                    && source.getAttacker() != null
                    && source.getAttacker().getCommandTags().contains(TAG)) {
                CORPSES.add(entity.getBlockPos());
            }
        });
    }

    private static boolean isGhost(VexEntity vex) {
        return vex.isAlive() && vex.getCommandTags().contains(TAG);
    }

    private static void tick(ServerWorld world) {
        if (world.getRegistryKey() != World.OVERWORLD) {
            return;
        }

        BlockPos corpse;
        while ((corpse = CORPSES.poll()) != null) {
            placeCorpse(world, corpse);
        }

        long time = world.getTime();
        ThreadLocalRandom random = ThreadLocalRandom.current();

        for (ServerPlayerEntity player : new ArrayList<>(world.getPlayers())) {
            if (player.isCreative() || player.isSpectator()) {
                continue;
            }

            // Caught: count down the scare, then kick.
            Integer remaining = GRABBED.get(player.getUuid());
            if (remaining != null) {
                if (remaining <= 1) {
                    kick(world, player);
                } else {
                    GRABBED.put(player.getUuid(), remaining - 1);
                }
                continue;
            }

            if (time % 4 == 0) {
                spawnMist(world, player);
            }

            if (player.age < GRACE_TICKS) {
                continue;
            }

            // Touch check (every tick).
            Box touchBox = player.getBoundingBox().expand(CATCH_DISTANCE);
            for (VexEntity ghost : world.getEntitiesByClass(VexEntity.class, touchBox, HauntManager::isGhost)) {
                if (ghost.squaredDistanceTo(player) < CATCH_DISTANCE * CATCH_DISTANCE) {
                    GRABBED.put(player.getUuid(), SCARE_TICKS);
                    ghost.playSound(SoundEvents.ENTITY_GHAST_SCREAM, 6.0F, 0.4F);
                    player.addStatusEffect(new StatusEffectInstance(StatusEffects.BLINDNESS, SCARE_TICKS + 60, 0));
                    player.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, SCARE_TICKS + 60, 6));
                    player.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, SCARE_TICKS + 60, 4));
                    break;
                }
            }

            if (time % 20 != 0 || GRABBED.containsKey(player.getUuid())) {
                continue;
            }

            // Once per second: retarget, spawn, atmosphere.
            Box area = player.getBoundingBox().expand(96.0);
            List<VexEntity> ghosts = world.getEntitiesByClass(VexEntity.class, area, HauntManager::isGhost);
            List<VillagerEntity> villagers = world.getEntitiesByClass(
                    VillagerEntity.class, player.getBoundingBox().expand(80.0), v -> v.isAlive());

            VexEntity nearest = null;
            double nearestSq = Double.MAX_VALUE;
            for (VexEntity ghost : ghosts) {
                retarget(world, ghost, player);
                double d = ghost.squaredDistanceTo(player);
                if (d < nearestSq) {
                    nearestSq = d;
                    nearest = ghost;
                }
            }

            if (nearest != null) {
                if (nearestSq < 16.0 * 16.0) {
                    nearest.playSound(SoundEvents.ENTITY_WARDEN_HEARTBEAT, 2.5F, 1.0F);
                }
                if (nearestSq < 10.0 * 10.0) {
                    player.addStatusEffect(new StatusEffectInstance(StatusEffects.DARKNESS, 80, 0));
                }
                if (random.nextInt(5) == 0) {
                    nearest.playSound(WHISPERS[random.nextInt(WHISPERS.length)], 2.0F, 0.5F + random.nextFloat() * 0.3F);
                }
            }

            int cap = GHOSTS_PER_PLAYER + (villagers.isEmpty() ? 0 : VILLAGE_EXTRA);
            int toSpawn = Math.min(cap - ghosts.size(), 3);
            for (int i = 0; i < toSpawn; i++) {
                if (!villagers.isEmpty() && random.nextInt(10) < 6) {
                    VillagerEntity anchor = villagers.get(random.nextInt(villagers.size()));
                    spawnGhostNear(world, anchor.getX(), anchor.getY(), anchor.getZ(), 6.0, 16.0, anchor);
                } else {
                    spawnGhostNear(world, player.getX(), player.getY(), player.getZ(), 28.0, 52.0, player);
                }
            }

            // Sometimes one appears right behind you.
            if (random.nextInt(30) == 0) {
                Vec3d look = player.getRotationVector();
                createGhost(world, player.getX() - look.x * 6.0, player.getY() + 1.0, player.getZ() - look.z * 6.0, player);
            }
        }
    }

    /** Ghosts go after the player when close, otherwise after the nearest animal or villager, otherwise the player. */
    private static void retarget(ServerWorld world, VexEntity ghost, ServerPlayerEntity player) {
        if (ghost.squaredDistanceTo(player) < 14.0 * 14.0) {
            ghost.setTarget(player);
            return;
        }

        PassiveEntity best = null;
        double bestSq = 24.0 * 24.0;
        for (PassiveEntity prey : world.getEntitiesByClass(PassiveEntity.class, ghost.getBoundingBox().expand(24.0), e -> e.isAlive())) {
            double d = ghost.squaredDistanceTo(prey);
            if (d < bestSq) {
                bestSq = d;
                best = prey;
            }
        }
        ghost.setTarget(best != null ? best : player);
    }

    private static void setAttribute(VexEntity ghost, RegistryEntry<EntityAttribute> attribute, double value) {
        EntityAttributeInstance instance = ghost.getAttributeInstance(attribute);
        if (instance != null) {
            instance.setBaseValue(value);
        }
    }

    private static void createGhost(ServerWorld world, double x, double y, double z, LivingEntity target) {
        VexEntity ghost = new VexEntity(EntityType.VEX, world);
        ghost.addCommandTag(TAG);
        setAttribute(ghost, EntityAttributes.GENERIC_SCALE, GHOST_SCALE);
        setAttribute(ghost, EntityAttributes.GENERIC_MAX_HEALTH, 40.0);
        ghost.setHealth(ghost.getMaxHealth());
        ghost.setPosition(x, y, z);
        ghost.setYaw(ThreadLocalRandom.current().nextFloat() * 360.0F);
        ghost.setTarget(target);
        world.spawnEntity(ghost);
        world.spawnParticles(ParticleTypes.SOUL, x, y + 1.0, z, 8, 0.3, 0.6, 0.3, 0.02);
    }

    private static void spawnGhostNear(ServerWorld world, double cx, double cy, double cz,
                                       double minDistance, double maxDistance, LivingEntity target) {
        ThreadLocalRandom random = ThreadLocalRandom.current();

        for (int attempt = 0; attempt < 6; attempt++) {
            double angle = random.nextDouble() * Math.PI * 2.0;
            double distance = minDistance + random.nextDouble() * (maxDistance - minDistance);
            int x = (int) Math.floor(cx + Math.cos(angle) * distance);
            int z = (int) Math.floor(cz + Math.sin(angle) * distance);

            if (!world.isChunkLoaded(x >> 4, z >> 4)) {
                continue;
            }

            BlockPos ground = findGround(world, new BlockPos(x, (int) Math.floor(cy) + 4, z), 14);
            if (ground != null) {
                createGhost(world, ground.getX() + 0.5, ground.getY() + 0.5, ground.getZ() + 0.5, target);
                return;
            }
        }
    }

    /** First position at or below {@code start} that is air with solid, dry ground under it and air above. */
    private static BlockPos findGround(ServerWorld world, BlockPos start, int maxDrop) {
        for (int i = 0; i < maxDrop; i++) {
            BlockPos feet = start.down(i);
            BlockPos below = feet.down();
            if (world.getBlockState(feet).isAir()
                    && world.getBlockState(feet.up()).isAir()
                    && !world.getBlockState(below).isAir()
                    && world.getFluidState(below).isEmpty()) {
                return feet;
            }
        }
        return null;
    }

    private static void spawnMist(ServerWorld world, ServerPlayerEntity player) {
        ThreadLocalRandom random = ThreadLocalRandom.current();
        for (int i = 0; i < 6; i++) {
            double x = player.getX() + random.nextDouble(-18.0, 18.0);
            double y = player.getY() + random.nextDouble(0.0, 3.0);
            double z = player.getZ() + random.nextDouble(-18.0, 18.0);
            world.spawnParticles(ParticleTypes.WHITE_ASH, x, y, z, 6, 2.0, 0.8, 2.0, 0.0);
        }
        double cx = player.getX() + random.nextDouble(-14.0, 14.0);
        double cz = player.getZ() + random.nextDouble(-14.0, 14.0);
        world.spawnParticles(ParticleTypes.CLOUD, cx, player.getY() + 0.3, cz, 2, 2.5, 0.2, 2.5, 0.0);
    }

    /** Corpse (zombie-head + brown robe) with blood splatters; stays forever. */
    private static void placeCorpse(ServerWorld world, BlockPos origin) {
        BlockPos ground = findGround(world, origin.up(2), 8);
        if (ground == null) {
            return;
        }

        ThreadLocalRandom random = ThreadLocalRandom.current();

        for (int i = 0; i < 16; i++) {
            BlockPos spot = findGround(world, ground.add(random.nextInt(-3, 4), 2, random.nextInt(-3, 4)), 6);
            if (spot != null) {
                world.setBlockState(spot, Blocks.RED_CARPET.getDefaultState());
            }
        }

        int[][] dirs = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};
        int[] dir = dirs[random.nextInt(dirs.length)];
        placeIfFree(world, ground, Blocks.ZOMBIE_HEAD);
        placeIfFree(world, ground.add(dir[0], 0, dir[1]), Blocks.BROWN_CARPET);
        placeIfFree(world, ground.add(dir[0] * 2, 0, dir[1] * 2), Blocks.BROWN_CARPET);
        world.spawnParticles(ParticleTypes.SOUL, ground.getX() + 0.5, ground.getY() + 1.0, ground.getZ() + 0.5, 20, 0.4, 0.8, 0.4, 0.03);
    }

    private static void placeIfFree(ServerWorld world, BlockPos pos, Block block) {
        BlockPos support = findGround(world, pos.up(), 3);
        if (support != null && support.getX() == pos.getX() && support.getZ() == pos.getZ()) {
            world.setBlockState(support, block.getDefaultState());
        }
    }

    private static void kick(ServerWorld world, ServerPlayerEntity player) {
        GRABBED.remove(player.getUuid());

        // Clear the ghosts near the player so rejoining is not an instant second kick.
        Box area = player.getBoundingBox().expand(64.0);
        for (VexEntity ghost : world.getEntitiesByClass(VexEntity.class, area, HauntManager::isGhost)) {
            ghost.discard();
        }

        player.networkHandler.disconnect(Text.literal("They caught you... Survive next time."));
    }
}
