package com.kodari.hauntedfog;

import net.fabricmc.api.ModInitializer;

public class HauntedFogMod implements ModInitializer {
    @Override
    public void onInitialize() {
        HauntManager.register();
    }
}
