HAUNTED FOG v2  (Minecraft 1.21 - 1.21.11, Fabric + Fabric API, Java 21)

* Overworld-e shobshomoy kuasa (mist).
* Join-er 30 second pore charidike 40ta boro, kalo, lal-chokh Ghost tomake tarao kore. Kokhono pichone hotath hajir hoy.
* Ghost kachhe ashle andho/dhushor hoye jay (Darkness), heartbeat ar fishfish shobdo shona jay.
* Ghost tomake chhule scream + andho, tarpor game tomake world theke berie dey.
* Village-er kache gele aro 20ta ghost ashe, shob villager ar animal mere fele.
  Villager mora gele tar lash (matha + jama) ar rokto (lal carpet) shesh obdhi thake.
* Creative/Spectator-e ghost kichu kore na (test).

Jar pete: GitHub-e notun repo, ei zip-er shob kichu (.github shoho) upload, Actions -> Build mod -> artifact.
